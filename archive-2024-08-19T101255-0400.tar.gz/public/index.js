const { Client, GatewayIntentBits, MessageActionRow, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const Groq = require('groq-sdk');
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 9442;

// Middleware to parse URL-encoded bodies (as sent by HTML forms)
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static files from the 'dist' directory
app.use(express.static(path.join(__dirname, 'dist')));

// Login Page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/dist/index.html'));
});

// Handle login form submission
app.get('/login', (req, res) => {
  const { email, password } = req.body;
  res.sendFile(path.join(__dirname, 'public/dist/index.html'));
  // Check credentials against environment variables
  if (email === process.env.LOGIN_USER && password === process.env.LOGIN_PASS) {
    // Redirect to /dashboard if login is successful
    res.redirect('/dashboard');
  } else {
    // Redirect back to the login page if login fails
    res.redirect('/');
  }
});

app.use('/css', express.static(path.join(__dirname, 'public', 'dist')));
app.use('/css', express.static(path.join(__dirname, 'public', 'src')));

// Serve the dashboard page
app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/dist/dashboard.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

// Initialize Groq with API key from environment variables
const groq = new Groq({ apiKey: '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' });
// Discord bot token 
const TOKEN = 'MTI1Mjg5Mjk0OTEyNjE4NDk3Mw.GELcdR.JNx1XKCHTDxfl8t9ZzpvQnDBoB0WOPaXoGqcdI';

// Initialize Discord Client with intents
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
});

const maxMessages = 8948; // Maximum messages to remember per server
const maxLogSize = 256 * 1024 * 1024; // 256 MB
const serverMessages = {};
const logsFilePath = path.join(__dirname, 'logs.json');

// Load logs.json if it exists
let logs = {};
if (fs.existsSync(logsFilePath)) {
    logs = JSON.parse(fs.readFileSync(logsFilePath, 'utf8'));
}

// Function to store messages per server
function rememberMessage(serverId, role, content) {
    if (!serverMessages[serverId]) {
        serverMessages[serverId] = [];
    }
    serverMessages[serverId].push({ role, content });

    if (serverMessages[serverId].length > maxMessages) {
        serverMessages[serverId].shift(); // Remove the oldest message
    }
}

// Function to determine if content is key information
function isKeyInformation(content) {
    // Define keywords or phrases that are indicative of key information
    const keyPhrases = [
        "name", "introduce", "about", "who am i", "my name", "i am", "character", "identity"
    ];

    // Check if content contains any of the key phrases
    return keyPhrases.some(phrase => content.toLowerCase().includes(phrase));
}

// Function to store key information in logs.json
async function storeKeyInformation(serverId, content) {
    try {
        const isKey = isKeyInformation(content);
        
        if (isKey) {
            if (!logs[serverId]) {
                logs[serverId] = [];
            }
            logs[serverId].push({ timestamp: new Date().toISOString(), keyInfo: content });

            // Write logs to logs.json
            fs.writeFileSync(logsFilePath, JSON.stringify(logs, null, 2), 'utf8');

            // Check if log file size exceeds the limit
            const stats = fs.statSync(logsFilePath);
            return stats.size > maxLogSize;
        }
        return false;
    } catch (error) {
        console.error("Groq API Error:", error);
        return false;
    }
}

// Function to get chat completion from Groq API with context preservation
async function getGroqChatCompletion(context) {
    try {
        const response = await groq.chat.completions.create({
            messages: context,
            model: 'llama3-8b-8192',
        });
        return response.choices[0]?.message?.content || "I couldn't generate a response.";
    } catch (error) {
        console.error("Groq API Error:", error);
        return "Sorry, I couldn't process your request.";
    }
}

// Function to split a long message into chunks
function splitMessage(message, limit = 2000) {
    if (message.length <= limit) return [message];

    const parts = [];
    let index = 0;
    while (index < message.length) {
        let nextPart = message.slice(index, index + limit);
        const lastSpace = nextPart.lastIndexOf(' ');
        if (lastSpace > 0 && index + limit < message.length) {
            nextPart = message.slice(index, index + lastSpace);
            index += lastSpace + 1;
        } else {
            index += limit;
        }
        parts.push(nextPart);
    }
    return parts;
}

// Command to reboot the bot
client.on('messageCreate', async message => {
    if (message.content === '!reboot') {
        const serverId = message.guild.id;

        // Collect and display key information for the server
        let keyInfoMessage = "Key information before reboot:\n";
        if (logs[serverId] && logs[serverId].length > 0) {
            keyInfoMessage += logs[serverId].map(log => {
                const timestamp = log.timestamp || "No timestamp";
                const keyInfo = log.keyInfo || "No key information";
                return `${timestamp}: ${keyInfo}`;
            }).join('\n');
        } else {
            keyInfoMessage += "No key information stored.";
        }

        const confirmButton = new ButtonBuilder()
            .setCustomId('confirm_reboot')
            .setLabel('Confirm Reboot')
            .setStyle(ButtonStyle.Danger);

        const cancelButton = new ButtonBuilder()
            .setCustomId('cancel_reboot')
            .setLabel('Cancel')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

        await message.channel.send({
            content: keyInfoMessage + "\n\nDo you want to reboot the bot? (Click 'Confirm Reboot' to proceed.)",
            components: [row]
        });

        const filter = interaction => ['confirm_reboot', 'cancel_reboot'].includes(interaction.customId) && interaction.user.id === message.author.id;
        const collector = message.channel.createMessageComponentCollector({ filter, time: 15000 });

        collector.on('collect', async interaction => {
            if (interaction.customId === 'confirm_reboot') {
                await interaction.update({
                    content: "Rebooting...",
                    components: []
                });

                // Clear memory for the server
                serverMessages[serverId] = [];

                // Clear key information from logs
                delete logs[serverId];
                fs.writeFileSync(logsFilePath, JSON.stringify(logs, null, 2));

                await interaction.followUp({
                    content: "Bot has been rebooted and memory has been cleared.",
                });
            } else {
                await interaction.update({
                    content: "Reboot cancelled.",
                    components: []
                });
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                message.channel.send("Reboot confirmation timed out.");
            }
        });

        return;
    }

    // Detect and store key information
    if (message.content.toLowerCase().includes('your name is')) {
        const name = message.content.split('your name is')[1].trim();
        const response = `Nice to meet you! I'm ${name}, nice and simple, just a humble AI assistant. What can I help you with today?`;

        rememberMessage(message.guild.id, 'user', message.content);
        rememberMessage(message.guild.id, 'assistant', response);

        const needsNotification = await storeKeyInformation(message.guild.id, `Bot name set to ${name}.`);

        if (needsNotification) {
            await message.channel.send("Key information stored. Please note that the log file size limit has been exceeded.");
        } else {
            await message.channel.send(response);
        }
        return;
    }

    // Handle !talk command
    if (message.content === '!talk') {
        await message.channel.send('Talking mode is active. To exit, type !exittalk.');

        const serverId = message.guild.id;
        let talkContext = serverMessages[serverId] || [];

        const talkCollector = message.channel.createMessageCollector({ filter: m => m.author.id === message.author.id });

        talkCollector.on('collect', async m => {
            if (m.content === '!exittalk') {
                await message.channel.send('Exiting talk mode.');
                talkCollector.stop();
            } else {
                talkContext.push({ role: 'user', content: m.content });
                const chatCompletion = await getGroqChatCompletion(talkContext);
                talkContext.push({ role: 'assistant', content: chatCompletion });

// Ensure the response doesn't exceed the 2000-character limit
const responseParts = splitMessage(chatCompletion);
for (const part of responseParts) {
    await message.channel.send(part);
}
}
});

return;
}

// Handle !blacklist command
if (message.content.startsWith('!blacklist')) {
    // Extract the user mention or ID
    const userToBlacklist = message.mentions.users.first() || await client.users.fetch(message.content.split(' ')[1]);

    if (!userToBlacklist) {
        await message.channel.send('Please mention a user or provide a valid user ID to blacklist.');
        return;
    }

    const confirmButton = new ButtonBuilder()
        .setCustomId('confirm_blacklist')
        .setLabel('Yes')
        .setStyle(ButtonStyle.Danger);

    const cancelButton = new ButtonBuilder()
        .setCustomId('cancel_blacklist')
        .setLabel('No')
        .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

    await message.channel.send({
        content: `Are you sure you want to blacklist ${userToBlacklist.username}?`,
        components: [row],
    });

    const filter = interaction => ['confirm_blacklist', 'cancel_blacklist'].includes(interaction.customId) && interaction.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 15000 });

    collector.on('collect', async interaction => {
        if (interaction.customId === 'confirm_blacklist') {
            // Ban the user
            await message.guild.members.ban(userToBlacklist, { reason: 'User was blacklisted.' });

            await interaction.update({
                content: `${userToBlacklist.username} has been blacklisted and banned.`,
                components: [],
            });

            // Store the blacklisted user ID
          if (!logs[serverId]['blacklistedUsers']) {
   			 logs[serverId]['blacklistedUsers'] = [];
			}
			logs[serverId]['blacklistedUsers'].push(userToBlacklist.id);

            fs.writeFileSync(logsFilePath, JSON.stringify(logs, null, 2), 'utf8');
        } else {
            await interaction.update({
                content: 'Blacklist action cancelled.',
                components: [],
            });
        }
    });

    collector.on('end', collected => {
        if (collected.size === 0) {
            message.channel.send('Blacklist confirmation timed out.');
        }
    });

    return;
}

// Example command to get a response from Groq
if (message.content.startsWith('!ask')) {
    const userQuery = message.content.slice(5); // Extract user query after "!ask "

    rememberMessage(message.guild.id, 'user', userQuery);
    const response = await getGroqChatCompletion([{ role: 'user', content: userQuery }]);

    rememberMessage(message.guild.id, 'assistant', response);
    const needsNotification = await storeKeyInformation(message.guild.id, userQuery);

    if (needsNotification) {
        await message.channel.send("Key information stored. Please note that the log file size limit has been exceeded.");
    } else {
        const responseParts = splitMessage(response);
        for (const part of responseParts) {
            await message.channel.send(part);
        }
    }
}
});

// Log in to Discord
client.login(TOKEN);